/*for (var a = 1; a <= 10; a++) {
	document.write("Hello World  <br>");
	console.log("Hello World on the Console")
}*/

function callForWork() {
	alert("alert Box Message");
	document.write("Hello World");
}
function addNumbers() {
	var n1 = parseInt(document.mathFrm.num1.value);
	var n2 = parseInt(document.mathFrm.num2.value);
	var n3 = n1+n2;
	document.mathFrm.ans.value = n3;
}