function validateRegistrationForm() {
	if (registerForm.firstName.value == "") {
		alert("Enter first name");
		return false;
	}
	else if (registerForm.lastName.value == "") {
		alert("Enter last name");
		return false;
	}
	else if (registerForm.emailId.value == "") {
		alert("Enter email Id");
		return false;
	}
	else if (registerForm.department.value == "") {
		alert("Enter department");
		return false;
	}
	else if (registerForm.designation.value == "") {
		alert("Enter designation");
		return false;
	}
	else if (registerForm.pancard.value == "") {
		alert("Enter pancard number");
		return false;
	}
	else if (registerForm.yearlyInvestmentUnder80C.value == "") {
		alert("Enter yearlyInvestmentUnder80C");
		return false;
	}
	else if (registerForm.basicSalary.value == "") {
		alert("Enter basicSalary");
		return false;
	}
	else if (registerForm.bankName.value == "") {
		alert("Enter bankName");
		return false;
	}
	else if (registerForm.accountNo.value == "") {
		alert("Enter accountNo");
		return false;
	}
	else if (registerForm.ifscCode.value == "") {
		alert("Enter ifscCode");
		return false;
	}	
}