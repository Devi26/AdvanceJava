package com.cg.project.beans;

import java.util.List;

public class UserBean {
	private int associateId;
	private String password, password1, firstName, lastName, emailId, mobileNo, gender, graduation;
	private List<String> communications;
	public UserBean() {}
	public UserBean(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}
	
	public UserBean(String password, String password1, String firstName, String lastName, String emailId, String mobileNo, String gender,
			String graduation, List<String> communications) {
		super();
		this.password = password;
		this.password1 = password1;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.graduation = graduation;
		this.communications = communications;
	}

	public int getAssociateId() {
		return associateId;
	}
	public String getPassword1() {
		return password1;
	}
	public void setPassword1(String password1) {
		this.password1 = password1;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public List<String> getCommunications() {
		return communications;
	}
	public void setCommunications(List<String> communications) {
		this.communications = communications;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + associateId;
		result = prime * result + ((communications == null) ? 0 : communications.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((graduation == null) ? 0 : graduation.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((password1 == null) ? 0 : password1.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBean other = (UserBean) obj;
		if (associateId != other.associateId)
			return false;
		if (communications == null) {
			if (other.communications != null)
				return false;
		} else if (!communications.equals(other.communications))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (graduation == null) {
			if (other.graduation != null)
				return false;
		} else if (!graduation.equals(other.graduation))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (password1 == null) {
			if (other.password1 != null)
				return false;
		} else if (!password1.equals(other.password1))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "UserBean [associateId=" + associateId + ", password=" + password + ", password1=" + password1
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + ", gender=" + gender + ", graduation=" + graduation + ", communications=" + communications
				+ "]";
	}
}
