package com.cg.project.controllers;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
          
    public RegistrationServlet() {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		//int associateId = Integer.parseInt(request.getParameter("associateId"));
		//String password = request.getParameter("password");
		/*String Register = request.getParameter("Register");
		String Reset = request.getParameter("Reset");*/

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String emailId = request.getParameter("emailId");
		String mobileNo = request.getParameter("mobileNo");
		String gender = request.getParameter("gender");
		String graduation = request.getParameter("graduation");
		String password = request.getParameter("password");
		String password1 = request.getParameter("password1");
		String [] communications = request.getParameterValues("communication");
		List<String> communication = Arrays.asList(communications);
	
		UserBean bean = new UserBean(password, password1,firstName, lastName, emailId, mobileNo, gender, graduation, communication);
		
		RequestDispatcher dispatcher = null;
		dispatcher = request.getRequestDispatcher("registrationSuccessPage.jsp");
		request.setAttribute("bean", bean);
		dispatcher.forward(request, response);
		
		/*out.println("<html><body>");
		out.println("<div>");
		
		out.println("<font color = 'Blue'>" + " firstName : "+ "<font color = 'green'>" +firstName + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " lastName : "+"<font color = 'green'>" +lastName + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " emailId : "+ "<font color = 'green'>" +emailId + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " mobileNo : "+ "<font color = 'green'>" +mobileNo + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " password : "+ "<font color = 'green'>" +password + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " Password1 : "+ "<font color = 'green'>" +password1 + "</font>" + "<br>");
		out.println("<font color = 'Blue'>" + " gender : "+ "<font color = 'green'>" +gender + "</font>" + "<br>");	
		out.println("<font color = 'Blue'>" + " graduation : "+ "<font color = 'green'>" +graduation + "</font>" + "<br>");	
		out.println("<font color = 'Blue'>" + " communication : "+ "<font color = 'green'>" +communication + "</font>" + "<br>");
		
		out.println("</div>");
		out.println("</html></body>");*/
	
	}

}
