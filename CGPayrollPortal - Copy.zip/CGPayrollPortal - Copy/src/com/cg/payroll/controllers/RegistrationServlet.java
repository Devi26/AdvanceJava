package com.cg.payroll.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    PayrollServices payrollServices=new PayrollServicesImpl();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String firstName=request.getParameter("firstName");
        String lastName=request.getParameter("lastName");
        String emailId=request.getParameter("emailId");
        String department=request.getParameter("department");
        String designation=request.getParameter("designation");
        String pancard=request.getParameter("panNo");
        int yearlyInvestmentUnder80c=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80c"));
        int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
        int epf=Integer.parseInt(request.getParameter("ePf"));
        int companyPf=Integer.parseInt(request.getParameter("companyPf"));
        String bankName=request.getParameter("bankName");
        int accountNumber=Integer.parseInt(request.getParameter("accountNo"));
        String ifscCode=request.getParameter("ifscCode");
        String password=request.getParameter("password");
    Associate associate=new Associate(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId, password, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
            try {
        int associateId=payrollServices.acceptAssociateDetails(associate);
        System.out.println("associateId:"+associateId);
    } catch (InvalidEmailException e) {     
        e.printStackTrace();
    }
    RequestDispatcher dispatcher=null;  
        dispatcher=request.getRequestDispatcher("registrationSuccessPage.jsp");
        request.setAttribute("associate", associate);
        dispatcher.forward(request, response);
    }
}