package com.cg.banking.services;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {

	private AccountDAO accountDAO = new AccountDAOImpl();
	private TransactionDAO transactionDAO = new TransactionDAOImpl();

	public BankingServicesImpl() {}

	public BankingServicesImpl(AccountDAO accountDAO, TransactionDAO transactionDAO) {
		super();
		this.accountDAO = accountDAO;
		this.transactionDAO = transactionDAO;
	}

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {

		Account account = new  Account(accountType, initBalance);
		account.setStatus("Active");
		account.setPinNumber(Integer.parseInt( String.format("%4d", new Random().nextInt(10000))));
		account = accountDAO.save(account);
		//account.setPinNumber((int) Math.random());
		Transaction transaction = new Transaction(initBalance, accountType);
		//transaction = transactionDAO.save(transaction);
		transaction.setTransactionType("Deposit");
		transactionDAO.update(transaction);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {

		Account account = this.getAccountDetails(accountNo);
		if(account==null) throw new AccountNotFoundException("Account doesn't exists.....");
		account.setAccountBalance(account.getAccountBalance() + amount);
		accountDAO.update(account);
		Transaction transaction = new Transaction(amount, account);
		transaction.setTransactionType("Deposit");
		transactionDAO.update(transaction);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {

		Account account = this.getAccountDetails(accountNo);
		if(account.getPinNumber() != pinNumber) throw new InvalidPinNumberException("The entered Pin Number is wrong, please enter valid Pin Number ");
		if(account.getAccountBalance() < amount) throw new  InsufficientAmountException("Your Account balance is lessthan " + amount + " , you can't withdraw the amount..");
		account.setAccountBalance(account.getAccountBalance()-amount);
		//float remainingBal =  account.getAccountBalance();
		accountDAO.update(account);
		Transaction transaction = new Transaction(amount, account);
		transaction.setTransactionType("Withdrawl");
		//		transactionDAO.save(transaction);
		transactionDAO.update(transaction);
		
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {

		Account accountFrom = this.getAccountDetails(accountNoFrom);
		Account accountTo = this.getAccountDetails(accountNoTo);
		Transaction transactionFrom = new Transaction(transferAmount, accountFrom);
		Transaction transactionTo = new Transaction(transferAmount, accountTo);
		transactionFrom.setTransactionType("Online");
		transactionTo.setTransactionType("Online");
		if(accountDAO.findOne(accountNoTo) == null && accountDAO.findOne(accountNoFrom) == null) throw new AccountNotFoundException("AccountNoTo is not found : " + accountNoTo);
		if(accountDAO.findOne(accountNoTo) == null && accountDAO.findOne(accountNoFrom) == null) throw new AccountBlockedException( " " + accountFrom + " or " + accountNoTo + "is Blocked.... ");
		if(accountFrom.getPinNumber() != pinNumber) throw new InvalidPinNumberException("The entered Pin Number is wrong, please enter valid Pin Number ");
		if(accountFrom.getAccountBalance() < transferAmount) throw new  InsufficientAmountException("Your Account balance is lessthan " + transferAmount + " , you can't transfer the amount..");
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		accountDAO.update(accountFrom);
		accountDAO.update(accountTo);
		/*transactionDAO.update(transactionFrom);
		transactionDAO.update(transactionTo);*/
		
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {

		Account account = new Account(accountNo);
		account = accountDAO.findOne( accountNo);
		//if(this.accountStatus(accountNo) == "Active");
		if(account == null) throw new AccountNotFoundException("Account DoesNot Exists........" + accountNo);
		Transaction transaction = new Transaction(account);
		transaction.setTransactionType("Mini Statement Checking.........");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return transactionDAO.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {

		Account account = new Account(accountNo);
		if(accountDAO.findOne(accountNo) == null) throw new AccountNotFoundException("Account Doesn't Exists : " + accountNo );
		if(account.getStatus() == null || account.getStatus() == "Blocked") throw new AccountBlockedException("Account Blocked : " + accountNo );
		else return "Active";
	}
}
