package com.cg.payroll.controllers;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/CalculateSalary")
public class CalculateSalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int associateID=Integer.parseInt(request.getParameter("associateID"));
		RequestDispatcher dispatcher=null;
		try {
			payrollServices.calculateNetSalary(associateID);
			Salary  salary=payrollServices.getAssociateDetails(associateID).getSalary();
			dispatcher=request.getRequestDispatcher("calculatedSalaryPage.jsp");
			request.setAttribute("salary", salary);
			dispatcher.forward(request, response);
		} catch (AssociateDetailsNotFoundException e) {             
			e.printStackTrace();
		}       
	}
}