package com.cg.payroll.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/GetAssociateDetails")
public class GetAssociateDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    PayrollServices payrollServices=new PayrollServicesImpl();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int associateId=Integer.parseInt(request.getParameter("associateID"));
        RequestDispatcher dispatcher=null;
        try {   
            Associate associate=payrollServices.getAssociateDetails(associateId);
            dispatcher=request.getRequestDispatcher("associateDetailsPage.jsp");
            request.setAttribute("associate", associate);
            dispatcher.forward(request, response);
        } catch (AssociateDetailsNotFoundException e) {         
            e.printStackTrace();
        }
    }

}