function validateRegistrationForm() {
	if (registerForm.firstName.value == "") {
		alert("Enter first name");
		return false;
	}
	else if (registerForm.lastName.value == "") {
		alert("Enter last name");
		return false;
	}
	else if (registerForm.emailId.value == "") {
		alert("Enter email Id");
		return false;
	}
	else if (registerForm.mobileNo.value == "") {
		alert("Enter mobileNo");
		return false;
	}
	else if (registerForm.designation.value == "") {
		alert("Enter gender");
		return false;
	}
	else if (registerForm.graduation.value == "") {
		alert("Enter graduation");
		return false;
	}
	else if (registerForm.password.value == "") {
		alert("Enter password");
		return false;
	}
	else if (registerForm.password1.value == "") {
		alert("Enter password1");
		return false;
	}
	else if (registerForm.communications.value == "") {
		alert("Enter communications");
		return false;
	}
}